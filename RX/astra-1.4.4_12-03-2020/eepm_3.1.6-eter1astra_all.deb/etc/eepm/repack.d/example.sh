#!/bin/sh
# Place your shell code here
# It will be run with two args: buildroot spec
# Name this script as package name

BUILDROOT="$1"
SPEC="$2"

